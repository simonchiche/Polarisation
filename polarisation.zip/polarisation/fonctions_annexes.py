# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 18:44:57 2020

@author: Simon
"""

def sinusoidal_fit_model(elevation, inclination, azimuth, vcrossB, vcross_vcrossB, zenith, energy,x, y, z, x_Xmax, y_Xmax, z_Xmax, save):

    pi = np.pi
    elevation = elevation*pi/180.0
    inclination = inclination*pi/180.0
    azimuth = azimuth*pi/180.0
    # unity vectors 
            
    uv = np.array([np.cos(elevation)*np.cos(azimuth), np.cos(elevation)*np.sin(azimuth) , -np.sin(elevation)])
    uB = np.array([np.cos(inclination), 0, -np.sin(inclination)])
    cos_alpha = np.dot(uv,uB)
    alpha = np.arccos(cos_alpha)

    
    phiG = pi   # angle géomagnétique    
    phiobs = np.arctan2(vcross_vcrossB,vcrossB) 
    phiC = np.arctan2(-vcross_vcrossB,-vcrossB)
     #rapport CE/geo
     
    a = np.array([0.0, 0.2, 0.4, 0.6, 0.8])
    for i in range(len(a)):
        K = a[i]/(np.abs(np.sin(alpha)))
        x_phiP_a = (np.sin(phiG)+ K*np.sin(phiC))
        y_phiP_a = (np.cos(phiG) + K*np.cos(phiC))
        phiP_a = np.arctan(x_phiP_a/y_phiP_a) #angle de polarisation en fonction de a
    
        Number_antenna = 8
    
        phiobs_cut = np.zeros(Number_antenna) # Retourne l'angle d'observation pour un nb d'antennes donné
        phiP_a_cut = np.zeros(Number_antenna)
    
    
        # On calcule toutes les valeurs des a
        for j in range(Number_antenna):
            index = j + 40
            phiobs_cut[j] = phiobs[index] 
            phiP_a_cut[j] = phiP_a[index]
    

        azimuth = azimuth*180/pi
    
    if(save == 'True'):
        plt.plot(phiobs_cut*180/pi, phiP_a_cut*180/pi, color = 'orange')
        #plt.legend(['model: a = %.3f' %a,'data'])
        plt.xlabel('$\phi_{obs}$ (degrees)')
        plt.ylabel('$\phi_{p}$ (degrees)')
        #plt.title('Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
        plt.ylim(-7,7)
        plt.tight_layout()
        plt.savefig('./images/Reconstruction/GeoCE_ratio/CE_geo_ratio_fit_%d.png' %100)
        plt.show()
    
    chi2 = 0 
    
    return chi2

def get_w(elevation, inclination, azimuth, x, y, z, x_Xmax, y_Xmax, z_Xmax):
    
    pi = np.pi
    elevation = elevation*pi/180.0
    inclination = inclination*pi/180.0
    azimuth = azimuth*pi/180.0
    
    x_antenna = x - x_Xmax
    y_antenna = y - y_Xmax
    z_antenna = z - z_Xmax
    
    uv = np.array([np.cos(elevation)*np.cos(azimuth), np.cos(elevation)*np.sin(azimuth) , -np.sin(elevation)])
    u_antenna = np.array([x_antenna, y_antenna, z_antenna])
    u_antenna /= np.linalg.norm(u_antenna, axis =0)
    w = np.arccos(np.dot(np.transpose(u_antenna), uv))
    w = w*180.0/pi
    #w = np.sort(w)
    
    return w

def sinusoidal_fit(a, elevation, inclination, azimuth, EvcrossB, Evcross_vcrossB, vcrossB, vcross_vcrossB, zenith, energy,x, y, z, x_Xmax, y_Xmax, z_Xmax, save, start):

    pi = np.pi
    elevation = elevation*pi/180.0
    inclination = inclination*pi/180.0
    azimuth = azimuth*pi/180.0
    # unity vectors 
            
    uv = np.array([np.cos(elevation)*np.cos(azimuth), np.cos(elevation)*np.sin(azimuth) , -np.sin(elevation)])
    uB = np.array([np.cos(inclination), 0, -np.sin(inclination)])
    cos_alpha = np.dot(uv,uB)
    alpha = np.arccos(cos_alpha)

    
    phiG = pi   # angle géomagnétique
    
    phiP = np.arctan(Evcross_vcrossB/EvcrossB) # angle de polarisation
    phiobs = np.arctan2(vcross_vcrossB,vcrossB) 
    phiC = np.arctan2(-vcross_vcrossB,-vcrossB)
     #rapport CE/geo
    K = a/(np.abs(np.sin(alpha)))
    x_phiP_a = (np.sin(phiG)+ K*np.sin(phiC))
    y_phiP_a = (np.cos(phiG) + K*np.cos(phiC))
    phiP_a = np.arctan(x_phiP_a/y_phiP_a) #angle de polarisation en fonction de a
    
    Number_antenna = 8
    
    phiobs_cut = np.zeros(Number_antenna) # Retourne l'angle d'observation pour un nb d'antennes donné
    phiP_cut = np.zeros(Number_antenna) # Retourne l'angle de polarisation pour un nb d'antennes donné
    phiP_a_cut = np.zeros(Number_antenna)
    
    
    # On calcule toutes les valeurs des a
    for i in range(Number_antenna):
        index = i + start
        phiobs_cut[i] = phiobs[index] 
        phiP_cut[i] = phiP[index]
        phiP_a_cut[i] = phiP_a[index]
    

    azimuth = azimuth*180/pi
    
    if(save == 'True'):
        plt.scatter(phiobs_cut*180/pi, phiP_cut*180/pi)
        plt.plot(phiobs_cut*180/pi, phiP_a_cut*180/pi, color = 'orange')
        plt.legend(['model: a = %.3f' %a,'data'])
        plt.xlabel('$\phi_{obs}$ (degrees)')
        plt.ylabel('$\phi_{p}$ (degrees)')
        #plt.title('Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
        plt.ylim(-7,7)
        plt.tight_layout()
        plt.savefig('./images/Reconstruction/GeoCE_ratio/CE_geo_ratio_fit_%d.png' %start)
        plt.show()
        
        plt.scatter(phiobs_cut*180/pi, phiP_cut*180/pi)
        plt.plot(phiobs_cut*180/pi, phiP_a_cut*180/pi, color = 'orange')
        plt.legend(['model: a = %.3f' %a,'data'])
        plt.xlabel('$\phi_{obs}$ (degrees)')
        plt.ylabel('$\phi_{p}$ (degrees)')
        #plt.title('Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
        plt.ylim(-7,7)
        plt.tight_layout()
        plt.savefig('./images/Reconstruction/GeoCE_ratio/CE_geo_ratio_fit_%d.png' %start)
        plt.show()
    
    chi2 = 0 
    
    for i in range(Number_antenna):
        chi2 = chi2 + ((phiP_cut[i]*180/pi - phiP_a_cut[i]*180/pi)**2)
    
    return chi2

def sinusoidal_fit_min(elevation, inclination, azimuth, EvcrossB, Evcross_vcrossB, vcrossB, vcross_vcrossB, zenith, energy, x, y, z, x_Xmax, y_Xmax, z_Xmax, start, save):
    
    dot = 1000
    a_var = np.linspace(0.,0.4,dot)
    chi2 = np.zeros(dot)
    
    for i in range(dot):    
        chi2[i] = sinusoidal_fit(a_var[i],elevation, inclination, azimuth, EvcrossB, Evcross_vcrossB, vcrossB, vcross_vcrossB, zenith, energy,x, y, z, x_Xmax, y_Xmax, z_Xmax, '', start)
    
    if(save == 'True'):
        plt.xlabel('$a = E_{ce}/E_{geo}$')
        plt.ylabel('$\chi^{2}$')
        #plt.title('Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
        imin = np.argmin(chi2)
        amin = a_var[imin]
        plt.plot(a_var, chi2)
        plt.legend(['$a_{min}$ $= %.3f$  $\chi^{2}_{min}$ = %.3f ' %(amin, np.min(chi2))])
        plt.tight_layout()
        plt.savefig('.chi2_ce_geo_ratio%d.png' %start)
        plt.show()
    
    sinusoidal_fit(amin,elevation, inclination, azimuth, EvcrossB, Evcross_vcrossB, vcrossB, vcross_vcrossB, zenith, energy, x, y, z, x_Xmax, y_Xmax, z_Xmax,'True', start)

    return amin  

def sinusoidal_fit_all(elevation, inclination, azimuth, EvcrossB, Evcross_vcrossB, vcrossB, vcross_vcrossB, zenith, energy, x, y, z, x_Xmax, y_Xmax, z_Xmax):
    
    n = len(EvcrossB) - 16
    w_circle = np.zeros(int(n/8.0))
    a = np.zeros(int(n/8.0))
    k = 0

    #pi = np.pi
    w =  get_w(elevation, inclination, azimuth, x, y, z, x_Xmax, y_Xmax, z_Xmax) 
    
    
    for i in range(n):
        if(i%8==0):
            a[k] = sinusoidal_fit_min(elevation, inclination, azimuth, EvcrossB, Evcross_vcrossB, vcrossB, vcross_vcrossB, zenith, energy, x, y, z, x_Xmax, y_Xmax, z_Xmax, i, 'True')
            w_circle[k] = np.mean(w[i:(i + 8)])
            k = k +1
    
    return (a,w_circle)

pi = np.pi
elevation = elevation*pi/180.0
inclination = inclination*pi/180.0
azimuth = azimuth*pi/180.0
# unity vectors 
        
uv = np.array([np.cos(elevation)*np.cos(azimuth), np.cos(elevation)*np.sin(azimuth) , -np.sin(elevation)])
uB = np.array([np.cos(inclination), 0, -np.sin(inclination)])
cos_alpha = np.dot(uv,uB)
alpha = np.arccos(cos_alpha)


phiG = pi   # angle géomagnétique    
phiobs = np.arctan2(vcross_vcrossB,vcrossB) 
phiC = np.arctan2(-vcross_vcrossB,-vcrossB)
 #rapport CE/geo
 
a = np.array([0.0, 0.05, 0.1, 0.15, 0.2])
for i in range(len(a)):
    K = a[i]/(np.abs(np.sin(alpha)))
    x_phiP_a = (np.sin(phiG)+ K*np.sin(phiC))
    y_phiP_a = (np.cos(phiG) + K*np.cos(phiC))
    phiP_a = np.arctan(x_phiP_a/y_phiP_a) #angle de polarisation en fonction de a

    Number_antenna = 8

    phiobs_cut = np.zeros(Number_antenna) # Retourne l'angle d'observation pour un nb d'antennes donné
    phiP_a_cut = np.zeros(Number_antenna)


    # On calcule toutes les valeurs des a
    for j in range(Number_antenna):
        index = j + 40
        phiobs_cut[j] = phiobs[index] 
        phiP_a_cut[j] = phiP_a[index]


    azimuth = azimuth*180/pi

    plt.plot(phiobs_cut*180/pi, phiP_a_cut*180/pi)
    #plt.legend(['model: a = %.3f' %a,'data'])
    plt.xlabel('$\phi_{obs}$ (degrees)')
    plt.ylabel('$\phi_{p}$ (degrees)')
    #plt.title('Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
    plt.ylim(-15,15)
    plt.tight_layout()
plt.legend(['a = 0.0', 'a = 0.05', 'a = 0.1', 'a = 0.15', 'a = 0.2' ], ncol = 1, bbox_to_anchor=(1.4, 1), loc = 'upper right', fontsize = 14)
#plt.tight_layout()
plt.savefig('harm_all.png', dpi = 400)
plt.show()


"""
Evxb_ce = np.zeros(n)
k = 0
for i in range(n):
    if((i%4!=0)&(i<160)):
        Evxb_ce[i] = Evxb[i] - Egeo[k]
        k = k +1
    else: 
        Evxvxb[i] = 0
"""

"""
plt.scatter(w_harm_nop, a_meanTim_nop)
plt.scatter(w_harm, a_meanTim, color = 'orange', marker = 'x')
plt.xlabel('w (degrees)')
plt.ylabel('ratio a')
plt.legend(['no noise', 'with noise'])
plt.title('(Tim) Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
plt.savefig('ratio_with_wo_noise_Tim%2.f_%2.f.png' %(energy, zenith))
plt.show()


plt.scatter(w_harm_nop, a_harm_nop)
plt.scatter(w_harm, a_harm, color = 'orange', marker = 'x')
plt.xlabel('w (degrees)')
plt.ylabel('ratio a')
plt.legend(['no noise', 'with noise'])
plt.title('(Harm) Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
plt.savefig('ratio_with_wo_noise_Harm%2.f_%2.f.png' %(energy, zenith))
plt.show()

diff_tim = np.abs(a_meanTim - a_meanTim_nop)
diff_harm = np.abs(a_harm - a_harm_nop)

plt.errorbar(w_harm_nop, a_meanTim_nop,yerr=diff_tim, fmt = 'o')
plt.xlabel('w (degrees)')
plt.ylabel('ratio a')
plt.title('(Tim) Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
plt.savefig('ratio_with_errors_Tim%2.f_%2.f.png' %(energy, zenith))
plt.show()

plt.errorbar(w_harm_nop, a_harm_nop,yerr=diff_harm, fmt = 'o')
plt.xlabel('w (degrees)')
plt.ylabel('ratio a')
plt.title('(harm) Azimuth $= %.0f \degree$ Zenith $= %.2f \degree$, Energy = %.3f Eev' %(azimuth, zenith, energy))
plt.savefig('ratio_with_errors_harm%2.f_%2.f.png' %(energy, zenith))
plt.show()
"""

def get_Eb(Ex_stokes, Ex, Ey_stokes, Ey, Ez, inclination):
   
    Eb_x_stokes = Ex_stokes*np.cos(inclination*180/np.pi)
    Eb_x = Ex*np.cos(inclination*180/np.pi)
    Eb_y = 0
    Eb_z = -Ez*np.sin(inclination*180/np.pi)

    Eb = np.sqrt(Eb_x**2 + Eb_z**2)
    Eb_stokes = np.sqrt(Eb_x_stokes**2 + Eb_z**2)
    Etot = np.sqrt(Ex**2 + Ey**2 + Ez**2)
    Etot_stokes = np.sqrt(Ex_stokes**2 + Ey_stokes**2 + Ez**2)

    return (Eb_x_stokes, Eb_x, Eb_y, Eb_z, Eb_stokes, Eb, Etot_stokes, Etot)

def get_polarisation_from_stokes_geo(Q, U, V, Exp2p, Eyp2p, trigger):
    
    
    Ip = np.sqrt(Q**2 + U**2 + V**2)
    Ip[np.sqrt(Ip)<trigger]= 0
    phiP = 0.5*np.arctan2(U,Q) + np.pi
    Etot_sp = np.sqrt(Ip)
    Evxb = abs(Etot_sp*np.cos(phiP))*np.sign(np.max(Exp2p))
    Evxvxb = abs(Etot_sp*np.sin(phiP))*np.sign(np.max(Eyp2p))
    Evxb[Evxb == 0] = 0  # à modifier
    Evxvxb[Evxvxb == 0] = 0 # à modifier
    r = np.sqrt(Evxb**2 + Evxvxb**2)
    
    return (Ip,Etot_sp, Evxb, Evxvxb, r, phiP)
