# -*- coding: utf-8 -*-
"""
Created on Thu May 21 22:39:15 2020

@author: Simon
"""

import numpy as np
import matplotlib.pyplot as plt
Traces = np.loadtxt('./data/trace.txt' ) # temporal traces of the electric field, the first 176 rows corresponds to the time related to the traces of each antenna. The 176 following rows to the Ex component of the traces, the 176 following rows to the Ey component etc   
x,y,z, Etot, Ex, Ey, Ez = np.loadtxt('./data/gamma_all.txt', unpack = True) #x, y, z : antenna positions
azimuth, elevation, zenith, inclination, energy, time_sample, x_Xmax, y_Xmax, z_Xmax = np.loadtxt('./data/parameters.txt', unpack = True)
from module_signal_process import add_noise_traces, digitalize_traces, filter_traces
from module_polarisation import get_in_shower_plane, get_stokes_parameters_time_all, get_time_window, get_mean_stokes_parameters_sp, get_polarisation_from_stokes, get_reconstruction, ce2geo_ratio, correct_early_late, get_max_stokes_parameters_sp, get_polarisation_from_absolute_traces, get_field_along_axis, sinusoidal_fit_all, Stokes_parameters_geo, get_mean_stokes_parameters_geo, get_Eb, get_core_reconstruction 
from module_polarisation_plot import plot_polarisation, plot_polarisation_vxvxb, plot_stokes_parameters, plot_total_field, plot_field_along_axis, plot_time_window, plot_polar_frac, plot_ce2geo_antennaid, plot_ce2geo_wcut, plot_ce2geo_wall, plot_ce2geo_harm_tim, plot_identification_geographic, plot_core_reconstruction
time_sample = int(len(Traces[:,0]))
n = len(x) #number of antennas
trigger = 100


# =============================================================================
#                            early-late correction
# =============================================================================

#(Traces, l_antennas, l0) = correct_early_late(x,y,z, x_Xmax, y_Xmax, z_Xmax, Traces)

# =============================================================================
#                                     Add noise
# =============================================================================

Traces = add_noise_traces(Traces,n , time_sample)

# =============================================================================
#                                    Filter
# =============================================================================

Traces = filter_traces(Traces,n, time_sample) 

# =============================================================================
#                                 Digitalize
# =============================================================================

(Traces, time_sample) = digitalize_traces(Traces,n, time_sample,  2)

# =============================================================================
#                               core reconstruction
# =============================================================================

(Ex_geo, Ey_geo, Ez_geo, Ip_geo, I_geo, Q_geo, U_geo, V_geo, I_antenna, r1_geo, r2_geo, time_min_geo, time_max_geo)  = get_mean_stokes_parameters_geo(Traces, n, time_sample, trigger) 
(Eb_x, Eb_z, Eb, Etot_geo) = get_Eb(n, Ex_geo, Ey_geo, Ez_geo, inclination)

(x_err_all, y_err_all, x_core_estimation, y_core_estimation, xmean, ymean) = get_core_reconstruction(n, 10000, 1, Eb, x, y, azimuth, zenith, energy, trigger)
plot_core_reconstruction(x_err_all, y_err_all, x_core_estimation, y_core_estimation, xmean, ymean, azimuth, zenith, energy, trigger)

# =============================================================================
#                               signal identification
# =============================================================================

plot_identification_geographic(Traces, n, time_sample, x, y, Eb, Etot_geo, I_geo, Ip_geo, azimuth, zenith, energy, inclination)

# =============================================================================
#                            Get in shower plane 
# =============================================================================

(v,vcrossB, vcross_vcrossB, Traces_Ev, Traces_EvcrossB, Traces_Evcross_vcrossB, Traces)  = get_in_shower_plane(x,y,z, Traces, time_sample, elevation, inclination,azimuth)

# =============================================================================
#                               Stokes parameters
# =============================================================================

# Stokes parameters as a function of time and time window
(I,Q,U,V) = get_stokes_parameters_time_all(Traces,time_sample,n)

(r1, r2, time_min, time_max) = get_time_window(Traces,time_sample,n, I)

# mean stokes parameters
(I_int, Q_int, U_int, V_int, Ip, polar_frac) = get_mean_stokes_parameters_sp(Traces, time_min, time_max,time_sample, n, 100.0)

# max of stokes parameters
(I_max, Q_max, U_max, V_max, Ipmax, polar_frac_max) =  get_max_stokes_parameters_sp(I,Q,U,V,n, 100.0)

# =============================================================================
#                                 Polarisation
# =============================================================================

# polarisation from mean stokes parameters
(Etot_sp, Evxb, Evxvxb, r, phiP) = get_polarisation_from_stokes(Ip, Q_int, U_int)

#polarisation from max of stokes parameters
(Etot_sp_max, Evxb_max, Evxvxb_max, rmax, phipmax) = get_polarisation_from_stokes(Ipmax, Q_max, U_max)


#polarisation from mean absolute traces
(Etot_sp_abs, Evxb_abs, Evxvxb_abs, rabs) = get_polarisation_from_absolute_traces(Traces, time_min, time_max, n, Etot, 100)

# =============================================================================
#                                   LDF
# =============================================================================

(position_along_vxb, position_along_vxvxb, EvcrossB_along_vxB, Evcross_vcrossB_along_vxB, EvcrossB_along_vxvxB, Evcross_vcrossB_along_vxvxB, Etot_along_vxB, Etot_along_vxvxB) = get_field_along_axis(vcrossB, vcross_vcrossB, Evxb, Evxvxb)

# =============================================================================
#                                Reconstruction
# =============================================================================

#Tim's method
(E_CE, Egeo, a, theta, alpha) = get_reconstruction(elevation,inclination, azimuth, vcrossB, vcross_vcrossB, Evxb, Evxvxb)
(theta, w, w_upl, w_upr, w_vertical, w_bl, w_br, a_upl, a_upr, a_vertical, a_bl, a_br, a_meanTim) = ce2geo_ratio(elevation, inclination, azimuth, x, y,z, x_Xmax, y_Xmax, z_Xmax, vcrossB, vcross_vcrossB, Evxb, Evxvxb, zenith, energy)

#Harm's method
(a_harm, w_harm) = sinusoidal_fit_all(elevation, inclination, azimuth, Evxb, Evxvxb, vcrossB, vcross_vcrossB, zenith, energy, x, y, z, x_Xmax, y_Xmax, z_Xmax, '')


# =============================================================================
#                               Plots
# =============================================================================

#plot total electric field
plot_total_field(vcrossB, vcross_vcrossB, Etot_sp, azimuth, zenith, energy, 'stokes')
       
#total polarisation
plot_polarisation(vcrossB, vcross_vcrossB, Etot_sp, Evxb, Evxvxb, r,  azimuth, zenith, energy, 'stokes')

#polarisation along vxvxb
plot_polarisation_vxvxb(vcrossB, vcross_vcrossB, Etot_sp, Evxvxb, azimuth, zenith, energy, 'stokes')

#stokes parameters
plot_stokes_parameters(vcrossB, vcross_vcrossB, I_int, Q_int, U_int, V_int, azimuth, zenith, energy, 'stokes')

#ldf
plot_field_along_axis(position_along_vxb, position_along_vxvxb, Etot_along_vxB, Etot_along_vxvxB, azimuth, zenith, energy, 'stokes')


#time window
plot_time_window(Traces, I, r1, r2, azimuth, zenith, energy, 24)
  

# fraction of polarised signal
plot_polar_frac(polar_frac, n, azimuth, zenith, energy, 'stokes')
plot_polar_frac(polar_frac_max, n, azimuth, zenith, energy, 'max')


# charge excess to geomagagnetic ratio
plot_ce2geo_antennaid(a, azimuth, zenith, energy, 'stokes') # as a function of the antenna id
plot_ce2geo_wcut(a, w, azimuth, zenith, energy, 'stokes') # as a function of w
plot_ce2geo_wall(a_upl, a_vertical, a_upr, a_br, a_bl, w_upl, w_vertical, w_upr, w_br, w_bl, azimuth, zenith, energy, 'stokes') # as a function of w distinguishing every arm    
plot_ce2geo_harm_tim(w_harm, a_harm, w_bl, w_br, w_upl, w_upr, w_vertical, a_bl, a_br, a_upl, a_upr, a_vertical, a_meanTim, azimuth, zenith, energy, 'stokes') # comparison between Harm's and Tim's method

# =============================================================================
#                                other
# =============================================================================
